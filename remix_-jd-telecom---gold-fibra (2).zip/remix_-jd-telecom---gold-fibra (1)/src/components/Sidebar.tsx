import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { Wifi, LogOut, UserCog, UserPlus, DollarSign, Settings as SettingsIcon, User as UserIcon, MessageCircle } from 'lucide-react';
import { useStore } from '@/store/useStore';

export const Sidebar = ({ isOpen, setIsOpen }: { isOpen: boolean; setIsOpen: (v: boolean) => void }) => {
  const logout = useStore((state) => state.logout);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const user = useStore((state) => state.user);
  const settings = useStore((state) => state.settings);
  const messages = useStore((state) => state.messages);

  const unreadCount = messages.filter(m => m.receiverId === user?.id && !m.read).length;

  const allNavItems = [
    { id: 'clientes', to: '/', icon: UserPlus, label: 'Cadastro de Clientes' },
    { id: 'planos', to: '/planos', icon: Wifi, label: 'Cadastro de Planos' },
    { id: 'usuarios', to: '/usuarios', icon: UserCog, label: 'Cadastro de Usuários' },
    { id: 'comissoes', to: '/comissoes', icon: DollarSign, label: 'Comissões e Valores' },
    { id: 'chat', to: '/chat', icon: MessageCircle, label: 'Chat Interno', badge: unreadCount },
    { id: 'configuracoes', to: '/configuracoes', icon: SettingsIcon, label: 'Configurações' },
  ];

  const navItems = allNavItems.filter(item => {
    if (item.id === 'chat') return true; // Everyone has access to chat
    if (item.id === 'configuracoes') return user?.role === 'admin';
    if (user?.allowedTabs && user.allowedTabs.length > 0) {
      return user.allowedTabs.includes(item.id);
    }
    if (user?.role === 'admin') return true;
    if (user?.role === 'atendente') return ['clientes', 'comissoes', 'chat'].includes(item.id);
    return false;
  });

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
      
      <aside className={`
        fixed top-0 left-0 z-30 h-screen w-64 bg-[#0A192F] text-white transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="flex items-center justify-center h-20 border-b border-white/10">
          {settings.logo ? (
            <img src={settings.logo} alt={settings.companyName} className="max-h-14 object-contain" />
          ) : (
            <div className="text-center">
              <h1 className="text-xl font-bold text-[#D4AF37]">{settings.companyName}</h1>
              <p className="text-xs text-gray-300 tracking-widest">{settings.companySubtitle}</p>
            </div>
          )}
        </div>

        <nav className="p-4 space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `
                flex items-center justify-between px-4 py-3 rounded-md transition-colors
                ${isActive ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-white/10 hover:text-white'}
              `}
              onClick={() => setIsOpen(false)}
            >
              <div className="flex items-center gap-3">
                <item.icon size={20} />
                <span className="font-medium">{item.label}</span>
              </div>
              {item.badge > 0 && (
                <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  {item.badge}
                </span>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="absolute bottom-0 w-full p-4 border-t border-white/10 bg-[#0A192F]">
          <div className="flex items-center gap-3 mb-4 px-2">
            {user?.photo ? (
              <img src={user.photo} alt={user.username} className="w-10 h-10 rounded-full object-cover border-2 border-[#D4AF37]" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center border-2 border-[#D4AF37]">
                <UserIcon className="text-gray-300" size={20} />
              </div>
            )}
            <div className="flex flex-col overflow-hidden flex-1 cursor-pointer hover:opacity-80 transition-opacity" onClick={() => navigate('/perfil')}>
              <span className="text-sm font-medium text-white truncate">{user?.username}</span>
              <span className="text-xs text-gray-400 capitalize">{user?.role}</span>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3 px-4 py-3 rounded-md text-red-400 hover:bg-red-400/10 transition-colors"
          >
            <LogOut size={20} />
            <span className="font-medium">Sair</span>
          </button>
        </div>
      </aside>
    </>
  );
};
