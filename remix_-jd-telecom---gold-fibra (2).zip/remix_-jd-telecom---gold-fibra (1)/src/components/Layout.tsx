import React, { useState, useEffect } from 'react';
import { Outlet, Navigate, Link } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { useStore } from '@/store/useStore';
import { Menu, AlertTriangle } from 'lucide-react';
import { differenceInDays } from 'date-fns';

export const Layout = () => {
  const user = useStore((state) => state.user);
  const license = useStore((state) => state.license);
  const updateUser = useStore((state) => state.updateUser);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    if (user && user.id && !user.isOnline) {
      updateUser(user.id, { isOnline: true });
    }
  }, [user, updateUser]);

  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'jd-telecom-storage') {
        useStore.persist.rehydrate();
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const isExpired = license.status === 'expired' || new Date() > new Date(license.expiresAt);
  if (isExpired) {
    return <Navigate to="/licenca" replace />;
  }

  const daysLeft = differenceInDays(new Date(license.expiresAt), new Date());
  const showTrialBanner = license.status === 'trial';

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {showTrialBanner && (
        <div className="bg-yellow-500 text-yellow-900 px-4 py-2 text-sm font-medium flex items-center justify-center gap-2 z-50">
          <AlertTriangle size={16} />
          <span>Você está usando uma versão de teste. Expira em {daysLeft} dias.</span>
          <Link to="/licenca" className="underline font-bold ml-2 hover:text-yellow-950">
            Assinar Agora
          </Link>
        </div>
      )}
      <div className="flex-1 flex">
        <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />
        
        <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center px-4 lg:px-8 sticky top-0 z-10">
          <button 
            className="lg:hidden p-2 mr-4 text-gray-600 hover:bg-gray-100 rounded-md"
            onClick={() => setIsSidebarOpen(true)}
          >
            <Menu size={24} />
          </button>
          <div className="flex-1"></div>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <span className="text-sm font-medium text-gray-700 hidden sm:block">
              {user.username}
            </span>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-8 overflow-auto">
          <div className="max-w-6xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
      </div>
    </div>
  );
};
