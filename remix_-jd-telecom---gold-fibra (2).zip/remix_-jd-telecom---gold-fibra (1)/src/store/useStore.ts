import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Customer, Plan, User, Settings, Message } from '../types';

export interface SaasPlan {
  id: string;
  name: string;
  periodDays: number;
  price: number;
}

export interface LicenseInfo {
  status: 'trial' | 'active' | 'expired';
  expiresAt: string;
}

interface AppState {
  user: User | null;
  login: (user: User) => void;
  logout: () => void;

  saasPlans: SaasPlan[];
  updateSaasPlan: (id: string, plan: Partial<SaasPlan>) => void;

  license: LicenseInfo;
  updateLicense: (license: Partial<LicenseInfo>) => void;

  settings: Settings;
  updateSettings: (settings: Partial<Settings>) => void;

  users: User[];
  addUser: (user: User) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  deleteUser: (id: string) => void;

  plans: Plan[];
  addPlan: (plan: Plan) => void;
  updatePlan: (id: string, plan: Partial<Plan>) => void;
  deletePlan: (id: string) => void;

  customers: Customer[];
  addCustomer: (customer: Customer) => void;
  updateCustomer: (id: string, customer: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;

  messages: Message[];
  sendMessage: (message: Omit<Message, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (senderId: string, receiverId: string) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      login: (user) => set((state) => {
        const newUsers = state.users.map(u => u.id === user.id ? { ...u, isOnline: true } : u);
        return { user: { ...user, isOnline: true }, users: newUsers };
      }),
      logout: () => set((state) => {
        if (state.user) {
          const newUsers = state.users.map(u => u.id === state.user!.id ? { ...u, isOnline: false } : u);
          return { user: null, users: newUsers };
        }
        return { user: null };
      }),

      saasPlans: [
        { id: '1', name: 'Plano Mensal', periodDays: 30, price: 149.90 },
        { id: '2', name: 'Plano Semestral', periodDays: 180, price: 799.90 },
        { id: '3', name: 'Plano Anual', periodDays: 365, price: 1499.90 },
      ],
      updateSaasPlan: (id, plan) => set((state) => ({
        saasPlans: state.saasPlans.map(p => p.id === id ? { ...p, ...plan } : p)
      })),

      license: {
        status: 'trial',
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days trial
      },
      updateLicense: (license) => set((state) => ({
        license: { ...state.license, ...license }
      })),

      settings: {
        companyName: 'JD Telecom',
        companySubtitle: 'GOLD FIBRA',
        logo: '',
        defaultObservation: 'Equipamentos cedidos em regime de comodato. Em caso de cancelamento, os equipamentos deverão ser devolvidos.',
      },
      updateSettings: (newSettings) => 
        set((state) => ({ settings: { ...state.settings, ...newSettings } })),

      users: [
        {
          id: '1',
          username: 'admin',
          password: '123456',
          role: 'admin',
          createdAt: new Date().toISOString(),
          allowedTabs: ['clientes', 'planos', 'usuarios', 'comissoes']
        }
      ],
      addUser: (user) => set((state) => ({ users: [...state.users, user] })),
      updateUser: (id, updatedUser) =>
        set((state) => {
          const newUsers = state.users.map((u) => (u.id === id ? { ...u, ...updatedUser } : u));
          const isCurrentUser = state.user?.id === id;
          return {
            users: newUsers,
            user: isCurrentUser ? { ...state.user, ...updatedUser } : state.user,
          };
        }),
      deleteUser: (id) =>
        set((state) => {
          const isCurrentUser = state.user?.id === id;
          return {
            users: state.users.filter((u) => u.id !== id),
            ...(isCurrentUser && { user: null }),
          };
        }),

      plans: [
        {
          id: '1',
          name: '600 Mega',
          speed: '600',
          price: 99.9,
          benefits: 'Wi-Fi 6, Suporte 24h',
          status: 'active',
        },
      ],
      addPlan: (plan) => set((state) => ({ plans: [...state.plans, plan] })),
      updatePlan: (id, updatedPlan) =>
        set((state) => ({
          plans: state.plans.map((p) => (p.id === id ? { ...p, ...updatedPlan } : p)),
        })),
      deletePlan: (id) =>
        set((state) => ({ plans: state.plans.filter((p) => p.id !== id) })),

      customers: [],
      addCustomer: (customer) =>
        set((state) => ({ customers: [...state.customers, customer] })),
      updateCustomer: (id, updatedCustomer) =>
        set((state) => ({
          customers: state.customers.map((c) => (c.id === id ? { ...c, ...updatedCustomer } : c)),
        })),
      deleteCustomer: (id) =>
        set((state) => ({ customers: state.customers.filter((c) => c.id !== id) })),

      messages: [],
      sendMessage: (msg) => set((state) => ({
        messages: [...state.messages, { ...msg, id: crypto.randomUUID(), timestamp: new Date().toISOString(), read: false }]
      })),
      markAsRead: (senderId, receiverId) => set((state) => {
        const hasUnread = state.messages.some(m => m.senderId === senderId && m.receiverId === receiverId && !m.read);
        if (!hasUnread) return state;
        return {
          messages: state.messages.map(m => 
            (m.senderId === senderId && m.receiverId === receiverId && !m.read) ? { ...m, read: true } : m
          )
        };
      }),
    }),
    {
      name: 'jd-telecom-storage',
    }
  )
);
