/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Login } from './pages/Login';
import { Customers } from './pages/Customers';
import { Plans } from './pages/Plans';
import { Users } from './pages/Users';
import { Commissions } from './pages/Commissions';
import { Settings } from './pages/Settings';
import { Profile } from './pages/Profile';
import { Chat } from './pages/Chat';
import { CPanel } from './pages/CPanel';
import { License } from './pages/License';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/cpanel" element={<CPanel />} />
        <Route path="/licenca" element={<License />} />
        <Route path="/" element={<Layout />}>
          <Route index element={<Customers />} />
          <Route path="planos" element={<Plans />} />
          <Route path="usuarios" element={<Users />} />
          <Route path="comissoes" element={<Commissions />} />
          <Route path="configuracoes" element={<Settings />} />
          <Route path="perfil" element={<Profile />} />
          <Route path="chat" element={<Chat />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
