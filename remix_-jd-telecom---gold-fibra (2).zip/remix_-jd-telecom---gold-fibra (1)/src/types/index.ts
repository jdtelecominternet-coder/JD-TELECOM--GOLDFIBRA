export interface User {
  id?: string;
  username: string;
  role: string;
  password?: string;
  createdAt?: string;
  defaultCommission?: number;
  allowedTabs?: string[];
  photo?: string;
  isOnline?: boolean;
}

export interface Settings {
  companyName: string;
  companySubtitle: string;
  logo?: string;
  defaultObservation?: string;
}

export interface Plan {
  id: string;
  name: string;
  speed: string;
  price: number;
  benefits: string;
  status: 'active' | 'inactive';
}

export interface Customer {
  id: string;
  fullName: string;
  cpf: string;
  birthDate: string;
  email: string;
  phone: string;
  cep: string;
  street: string;
  number: string;
  neighborhood: string;
  city: string;
  state: string;
  dueDate: string;
  planId: string;
  observations: string;
  createdAt: string;
  createdBy?: string;
  commissionValue?: number;
  commissionStatus?: 'pendente' | 'pago' | 'cancelado';
  installationShift?: 'Manhã' | 'Tarde';
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
}
