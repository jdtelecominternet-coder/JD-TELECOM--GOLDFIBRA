import React from 'react';
import { useStore } from '@/store/useStore';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Save, User as UserIcon } from 'lucide-react';
import { Navigate } from 'react-router-dom';

const profileSchema = z.object({
  username: z.string().min(3, 'Usuário deve ter no mínimo 3 caracteres'),
  password: z.string().optional(),
  photo: z.string().optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;

export const Profile = () => {
  const { user, users, updateUser } = useStore();
  const [showSuccess, setShowSuccess] = React.useState(false);

  const currentUserData = users.find(u => u.id === user?.id);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      username: currentUserData?.username || '',
      password: currentUserData?.password || '',
      photo: currentUserData?.photo || '',
    },
  });

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setValue('photo', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = (data: ProfileFormData) => {
    if (user.id) {
      updateUser(user.id, {
        username: data.username,
        password: data.password || currentUserData?.password,
        photo: data.photo,
      });
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Meu Perfil</h1>
        <p className="text-sm text-gray-500">
          Atualize suas informações pessoais e foto de perfil.
        </p>
      </div>

      {showSuccess && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative" role="alert">
          <span className="block sm:inline">Perfil atualizado com sucesso!</span>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Foto de Perfil
              </label>
              <div className="flex items-center gap-4">
                {watch('photo') ? (
                  <img src={watch('photo')} alt="Preview" className="w-20 h-20 rounded-full object-cover border-2 border-gray-200" />
                ) : (
                  <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center border-2 border-gray-200">
                    <UserIcon className="text-gray-400" size={32} />
                  </div>
                )}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                />
              </div>
            </div>

            <Input
              label="Nome de Usuário"
              placeholder="Seu nome de usuário"
              {...register('username')}
              error={errors.username?.message}
            />

            <Input
              label="Nova Senha (deixe em branco para não alterar)"
              type="password"
              placeholder="******"
              {...register('password')}
              error={errors.password?.message}
            />
          </div>

          <div className="flex justify-end pt-4 border-t">
            <Button type="submit" className="gap-2">
              <Save size={18} /> Salvar Alterações
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
