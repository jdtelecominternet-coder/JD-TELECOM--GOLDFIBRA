import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import { jsPDF } from 'jspdf';
import { format } from 'date-fns';
import { useStore } from '@/store/useStore';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Select';
import { maskCEP, maskCPF, maskPhone } from '@/lib/utils';
import { FileText, Save, Eraser, Plus, Edit2, Trash2, X, Search } from 'lucide-react';
import { Customer } from '@/types';

const customerSchema = z.object({
  fullName: z.string().min(3, 'Nome completo é obrigatório'),
  cpf: z.string().min(14, 'CPF inválido'),
  birthDate: z.string().min(1, 'Data de nascimento é obrigatória'),
  email: z.string().email('E-mail inválido'),
  phone: z.string().min(14, 'Telefone inválido'),
  cep: z.string().min(9, 'CEP inválido'),
  street: z.string().min(1, 'Rua é obrigatória'),
  number: z.string().min(1, 'Número é obrigatório'),
  neighborhood: z.string().min(1, 'Bairro é obrigatório'),
  city: z.string().min(1, 'Cidade é obrigatória'),
  state: z.string().min(2, 'Estado é obrigatório'),
  dueDate: z.string().min(1, 'Vencimento é obrigatório'),
  planId: z.string().min(1, 'Selecione um plano'),
  observations: z.string().optional(),
  installationShift: z.enum(['Manhã', 'Tarde']).optional(),
});

type CustomerFormData = z.infer<typeof customerSchema>;

export const Customers = () => {
  const { plans, customers, users, settings, addCustomer, updateCustomer, deleteCustomer, user: currentUser } = useStore();
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors },
  } = useForm<CustomerFormData>({
    resolver: zodResolver(customerSchema),
  });

  const cepValue = watch('cep');

  const handleCepBlur = async () => {
    if (cepValue && cepValue.length === 9) {
      try {
        const cleanCep = cepValue.replace(/\D/g, '');
        const response = await axios.get(`https://viacep.com.br/ws/${cleanCep}/json/`);
        if (!response.data.erro) {
          setValue('street', response.data.logradouro);
          setValue('neighborhood', response.data.bairro);
          setValue('city', response.data.localidade);
          setValue('state', response.data.uf);
        }
      } catch (error) {
        console.error('Erro ao buscar CEP:', error);
      }
    }
  };

  const onSubmit = (data: CustomerFormData) => {
    if (isEditing) {
      updateCustomer(isEditing, data);
      alert('Cliente atualizado com sucesso!');
    } else {
      const actualUser = users.find(u => u.id === currentUser?.id);
      const newCustomer: Customer = {
        ...data,
        id: crypto.randomUUID(),
        observations: data.observations || '',
        createdAt: new Date().toISOString(),
        createdBy: currentUser?.id,
        commissionValue: actualUser?.defaultCommission || 0,
        commissionStatus: 'pendente',
      };
      addCustomer(newCustomer);
      alert('Cliente cadastrado com sucesso!');
    }
    handleCloseForm();
  };

  const handleEdit = (customer: Customer) => {
    setIsEditing(customer.id);
    setValue('fullName', customer.fullName);
    setValue('cpf', customer.cpf);
    setValue('birthDate', customer.birthDate);
    setValue('email', customer.email);
    setValue('phone', customer.phone);
    setValue('cep', customer.cep);
    setValue('street', customer.street);
    setValue('number', customer.number);
    setValue('neighborhood', customer.neighborhood);
    setValue('city', customer.city);
    setValue('state', customer.state);
    setValue('dueDate', customer.dueDate);
    setValue('planId', customer.planId);
    setValue('observations', customer.observations || '');
    setValue('installationShift', customer.installationShift);
    setShowForm(true);
  };

  const handleOpenNewForm = () => {
    reset({
      observations: settings.defaultObservation || '',
    });
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setIsEditing(null);
    reset();
  };

  const generatePDF = (customer: Customer, action: 'download' | 'print' = 'download') => {
    setIsGeneratingPDF(true);
    try {
      const doc = new jsPDF();
      const plan = plans.find(p => p.id === customer.planId);

      // Header
      doc.setFillColor(10, 25, 47); // #0A192F
      doc.rect(0, 0, 210, 40, 'F');
      
      doc.setTextColor(212, 175, 55); // #D4AF37 Gold
      doc.setFontSize(24);
      doc.setFont('helvetica', 'bold');
      doc.text(settings.companyName, 105, 20, { align: 'center' });
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.text(`${settings.companySubtitle} - CONTRATO DE PRESTAÇÃO DE SERVIÇOS`, 105, 30, { align: 'center' });

      // Body
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('DADOS DO CLIENTE', 20, 55);
      
      doc.setFontSize(11);
      doc.setFont('helvetica', 'normal');
      const startY = 65;
      const lineH = 8;
      
      doc.text(`Nome: ${customer.fullName}`, 20, startY);
      doc.text(`CPF: ${customer.cpf}`, 120, startY);
      
      let formattedDate = customer.birthDate;
      if (customer.birthDate && customer.birthDate.includes('-')) {
        const [year, month, day] = customer.birthDate.split('-');
        formattedDate = `${day}/${month}/${year}`;
      }
      doc.text(`Data de Nasc.: ${formattedDate}`, 20, startY + lineH);
      doc.text(`Telefone: ${customer.phone}`, 120, startY + lineH);
      
      doc.text(`E-mail: ${customer.email}`, 20, startY + lineH * 2);
      
      doc.text(`Endereço: ${customer.street}, ${customer.number}`, 20, startY + lineH * 3);
      doc.text(`Bairro: ${customer.neighborhood}`, 20, startY + lineH * 4);
      doc.text(`Cidade/UF: ${customer.city} - ${customer.state}`, 120, startY + lineH * 4);
      doc.text(`CEP: ${customer.cep}`, 20, startY + lineH * 5);

      // Plan Details
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('DADOS DO PLANO', 20, startY + lineH * 7);
      
      doc.setFontSize(11);
      doc.setFont('helvetica', 'normal');
      if (plan) {
        doc.text(`Plano Escolhido: ${plan.name} (${plan.speed} Mega)`, 20, startY + lineH * 8);
        doc.text(`Valor Mensal: R$ ${plan.price.toFixed(2).replace('.', ',')}`, 120, startY + lineH * 8);
        doc.text(`Benefícios: ${plan.benefits}`, 20, startY + lineH * 9);
      } else {
        doc.text('Plano não encontrado.', 20, startY + lineH * 8);
      }
      doc.text(`Vencimento da Fatura: Dia ${customer.dueDate}`, 20, startY + lineH * 10);
      doc.text(`Turno de Instalação: ${customer.installationShift || 'Não informado'}`, 120, startY + lineH * 10);

      // Observations
      if (customer.observations && typeof customer.observations === 'string') {
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text('OBSERVAÇÕES', 20, startY + lineH * 12);
        doc.setFontSize(11);
        doc.setFont('helvetica', 'normal');
        
        const splitObs = doc.splitTextToSize(customer.observations, 170);
        doc.text(splitObs, 20, startY + lineH * 13);
      }

      // Footer / Signatures
      const sigY = 230;
      doc.line(30, sigY, 90, sigY);
      doc.text('Assinatura do Cliente', 60, sigY + 5, { align: 'center' });
      
      doc.line(120, sigY, 180, sigY);
      doc.text(`${settings.companyName} - ${settings.companySubtitle}`, 150, sigY + 5, { align: 'center' });

      doc.setFontSize(9);
      doc.text(`Gerado em: ${format(new Date(), 'dd/MM/yyyy HH:mm')}`, 105, 280, { align: 'center' });

      if (action === 'print') {
        doc.autoPrint();
        const blob = doc.output('blob');
        const url = URL.createObjectURL(blob);
        window.open(url, '_blank');
      } else {
        doc.save(`Contrato_${customer.fullName.replace(/\s+/g, '_')}.pdf`);
      }
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      alert('Erro ao gerar PDF.');
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const activePlans = plans.filter(p => p.status === 'active');

  // Filtro de clientes: Por permissão (RBAC) e por busca
  const filteredCustomers = customers.filter(customer => {
    // 1. RBAC: Admin vê todos, Atendente vê apenas os que ele mesmo cadastrou
    if (currentUser?.role !== 'admin' && customer.createdBy !== currentUser?.id) {
      return false;
    }
    
    // 2. Busca por nome, CPF ou email
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return (
        customer.fullName.toLowerCase().includes(term) ||
        customer.cpf.includes(term) ||
        customer.email.toLowerCase().includes(term)
      );
    }
    
    return true;
  });

  const hasAccess = currentUser?.allowedTabs && currentUser.allowedTabs.length > 0
    ? currentUser.allowedTabs.includes('clientes')
    : true;

  if (!hasAccess) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500 text-lg">Você não tem permissão para acessar esta página.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Cadastro de Clientes</h1>
          <p className="text-sm text-gray-500">
            {currentUser?.role === 'admin' 
              ? 'Gerencie todos os clientes e gere contratos em PDF.' 
              : 'Gerencie os seus clientes cadastrados e gere contratos em PDF.'}
          </p>
        </div>
        {!showForm && (
          <Button onClick={handleOpenNewForm} className="gap-2">
            <Plus size={18} /> Novo Cliente
          </Button>
        )}
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-800">
              {isEditing ? 'Editar Cliente' : 'Cadastrar Novo Cliente'}
            </h2>
            <button onClick={handleCloseForm} className="text-gray-400 hover:text-gray-600">
              <X size={20} />
            </button>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            
            {/* Dados Pessoais */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4 border-b pb-2">Dados Pessoais</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input
                  label="Nome Completo"
                  placeholder="João da Silva"
                  {...register('fullName')}
                  error={errors.fullName?.message}
                />
                <Input
                  label="CPF"
                  placeholder="000.000.000-00"
                  {...register('cpf')}
                  onChange={(e) => {
                    e.target.value = maskCPF(e.target.value);
                    setValue('cpf', e.target.value);
                  }}
                  error={errors.cpf?.message}
                  maxLength={14}
                />
                <Input
                  label="Data de Nascimento"
                  type="date"
                  {...register('birthDate')}
                  error={errors.birthDate?.message}
                />
                <Input
                  label="E-mail"
                  type="email"
                  placeholder="joao@email.com"
                  {...register('email')}
                  error={errors.email?.message}
                />
                <Input
                  label="Telefone"
                  placeholder="(00) 00000-0000"
                  {...register('phone')}
                  onChange={(e) => {
                    e.target.value = maskPhone(e.target.value);
                    setValue('phone', e.target.value);
                  }}
                  error={errors.phone?.message}
                  maxLength={15}
                />
              </div>
            </div>

            {/* Endereço */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4 border-b pb-2">Endereço</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input
                  label="CEP"
                  placeholder="00000-000"
                  {...register('cep')}
                  onChange={(e) => {
                    e.target.value = maskCEP(e.target.value);
                    setValue('cep', e.target.value);
                  }}
                  onBlur={handleCepBlur}
                  error={errors.cep?.message}
                  maxLength={9}
                />
                <div className="md:col-span-2">
                  <Input
                    label="Rua / Logradouro"
                    placeholder="Rua das Flores"
                    {...register('street')}
                    error={errors.street?.message}
                  />
                </div>
                <Input
                  label="Número"
                  placeholder="123"
                  {...register('number')}
                  error={errors.number?.message}
                />
                <Input
                  label="Bairro"
                  placeholder="Centro"
                  {...register('neighborhood')}
                  error={errors.neighborhood?.message}
                />
                <Input
                  label="Cidade"
                  placeholder="São Paulo"
                  {...register('city')}
                  error={errors.city?.message}
                />
                <Input
                  label="Estado (UF)"
                  placeholder="SP"
                  {...register('state')}
                  error={errors.state?.message}
                  maxLength={2}
                />
              </div>
            </div>

            {/* Plano e Faturamento */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4 border-b pb-2">Plano e Faturamento</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Select
                  label="Plano Escolhido"
                  options={activePlans.map(p => ({ value: p.id, label: `${p.name} - R$ ${p.price.toFixed(2)}` }))}
                  {...register('planId')}
                  error={errors.planId?.message}
                />
                <Select
                  label="Dia de Vencimento"
                  options={[
                    { value: '5', label: 'Dia 5' },
                    { value: '10', label: 'Dia 10' },
                    { value: '15', label: 'Dia 15' },
                    { value: '20', label: 'Dia 20' },
                    { value: '25', label: 'Dia 25' },
                  ]}
                  {...register('dueDate')}
                  error={errors.dueDate?.message}
                />
                <Select
                  label="Turno de Instalação"
                  options={[
                    { value: 'Manhã', label: 'Manhã' },
                    { value: 'Tarde', label: 'Tarde' },
                  ]}
                  {...register('installationShift')}
                  error={errors.installationShift?.message}
                />
                <div className="md:col-span-3">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Observações
                  </label>
                  <textarea
                    className="flex w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-500"
                    rows={3}
                    placeholder="Informações adicionais para instalação..."
                    {...register('observations')}
                    disabled={currentUser?.role !== 'admin'}
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-4 pt-4 border-t">
              <Button type="button" variant="outline" onClick={handleCloseForm} className="gap-2">
                Cancelar
              </Button>
              <Button type="submit" className="gap-2">
                <Save size={18} /> {isEditing ? 'Salvar Alterações' : 'Salvar Cliente'}
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Lista de Clientes */}
      <div>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
          <h3 className="text-lg font-medium text-gray-900">
            {currentUser?.role === 'admin' ? 'Todos os Clientes' : 'Meus Clientes Cadastrados'}
          </h3>
          <div className="relative w-full sm:w-72">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Buscar por nome, CPF ou e-mail..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-gray-500">
              <thead className="bg-gray-50 text-xs uppercase text-gray-700">
                <tr>
                  <th className="px-6 py-4 font-medium">Nome</th>
                  <th className="px-6 py-4 font-medium">CPF</th>
                  <th className="px-6 py-4 font-medium">Plano</th>
                  <th className="px-6 py-4 font-medium">Comissão</th>
                  <th className="px-6 py-4 font-medium">Data Cadastro</th>
                  <th className="px-6 py-4 font-medium text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredCustomers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                      Nenhum cliente encontrado.
                    </td>
                  </tr>
                ) : (
                  filteredCustomers.slice().reverse().map((customer) => {
                    const plan = plans.find(p => p.id === customer.planId);
                    return (
                      <tr key={customer.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium text-gray-900">{customer.fullName}</td>
                        <td className="px-6 py-4">{customer.cpf}</td>
                        <td className="px-6 py-4">{plan?.name || 'Plano não encontrado'}</td>
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="font-medium text-gray-900">
                              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(customer.commissionValue || 0)}
                            </span>
                            <span className={`text-[10px] font-medium uppercase ${
                              customer.commissionStatus === 'pago' ? 'text-green-600' : 
                              customer.commissionStatus === 'cancelado' ? 'text-red-600' : 'text-yellow-600'
                            }`}>
                              {customer.commissionStatus || 'pendente'}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4">{format(new Date(customer.createdAt), 'dd/MM/yyyy')}</td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="gap-2 text-blue-600 border-blue-200 hover:bg-blue-50"
                              onClick={() => generatePDF(customer, 'download')}
                              disabled={isGeneratingPDF}
                              title="Download PDF"
                            >
                              <FileText size={16} />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="gap-2 text-gray-600 border-gray-200 hover:bg-gray-50"
                              onClick={() => generatePDF(customer, 'print')}
                              disabled={isGeneratingPDF}
                              title="Imprimir"
                            >
                              <FileText size={16} />
                            </Button>
                            <button
                              onClick={() => handleEdit(customer)}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                              title="Editar Cliente"
                            >
                              <Edit2 size={16} />
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(customer.id)}
                              className="p-1.5 text-red-600 hover:bg-red-50 rounded-md transition-colors"
                              title="Excluir Cliente"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Confirmar Exclusão</h3>
            <p className="text-gray-600 mb-6">Tem certeza que deseja excluir este cliente? Esta ação não pode ser desfeita.</p>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setDeleteConfirmId(null)}>Cancelar</Button>
              <Button 
                className="bg-red-600 hover:bg-red-700 text-white"
                onClick={() => {
                  deleteCustomer(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
              >
                Excluir
              </Button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
