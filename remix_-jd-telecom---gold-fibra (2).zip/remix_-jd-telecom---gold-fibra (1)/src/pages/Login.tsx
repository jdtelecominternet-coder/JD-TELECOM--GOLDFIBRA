import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store/useStore';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Wifi } from 'lucide-react';

export const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const login = useStore((state) => state.login);
  const users = useStore((state) => state.users);
  const settings = useStore((state) => state.settings);
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const foundUser = users.find(u => u.username === username && u.password === password);

    if (foundUser) {
      login({ id: foundUser.id, username: foundUser.username, role: foundUser.role });
      navigate('/');
    } else {
      setError('Credenciais inválidas. Verifique seu usuário e senha.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center text-[#0A192F]">
          {settings.logo ? (
            <img src={settings.logo} alt={settings.companyName} className="h-20 object-contain" />
          ) : (
            <Wifi size={48} className="text-[#D4AF37]" />
          )}
        </div>
        {!settings.logo && (
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            {settings.companyName}
          </h2>
        )}
        <p className="mt-2 text-center text-sm text-gray-600">
          {settings.companySubtitle} - Sistema de Gestão
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-gray-100">
          <form className="space-y-6" onSubmit={handleLogin}>
            <Input
              label="Usuário"
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="admin"
            />

            <Input
              label="Senha"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="******"
            />

            {error && (
              <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-100">
                {error}
              </div>
            )}

            <Button type="submit" className="w-full" size="lg">
              Entrar no Sistema
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
};
