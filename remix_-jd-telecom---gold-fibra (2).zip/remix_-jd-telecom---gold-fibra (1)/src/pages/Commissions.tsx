import React, { useState } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/Button';
import { FileText, CheckCircle, Clock, Edit2, Save, X } from 'lucide-react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';

export const Commissions = () => {
  const { customers, users, plans, updateCustomer, user: currentUser } = useStore();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [editStatus, setEditStatus] = useState<'pendente' | 'pago' | 'cancelado'>('pendente');

  const isAdmin = currentUser?.role === 'admin';

  // Admin vê todos os clientes, Atendente vê apenas os que ele cadastrou
  const filteredCustomers = isAdmin 
    ? customers 
    : customers.filter(c => c.createdBy === currentUser?.id);

  const totalPendente = filteredCustomers
    .filter(c => !c.commissionStatus || c.commissionStatus === 'pendente')
    .reduce((acc, c) => acc + (c.commissionValue || 0), 0);

  const totalPago = filteredCustomers
    .filter(c => c.commissionStatus === 'pago')
    .reduce((acc, c) => acc + (c.commissionValue || 0), 0);

  const handleSaveValue = (id: string) => {
    updateCustomer(id, { 
      commissionValue: parseFloat(editValue) || 0,
      commissionStatus: editStatus
    });
    setEditingId(null);
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    
    // Header
    doc.setFillColor(10, 25, 47);
    doc.rect(0, 0, 210, 30, 'F');
    doc.setTextColor(212, 175, 55);
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text('JD Telecom - Relatório de Comissões e Recebimentos', 105, 20, { align: 'center' });

    // Resumo
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('Resumo Financeiro:', 14, 40);
    
    doc.setFont('helvetica', 'normal');
    doc.text(`Total Pendente: R$ ${totalPendente.toFixed(2).replace('.', ',')}`, 14, 48);
    doc.text(`Total Pago: R$ ${totalPago.toFixed(2).replace('.', ',')}`, 14, 56);
    doc.text(`Gerado em: ${format(new Date(), 'dd/MM/yyyy HH:mm')}`, 14, 64);
    
    if (!isAdmin) {
      doc.text(`Vendedor: ${currentUser?.username}`, 14, 72);
    }

    // Tabela
    const tableData = filteredCustomers.slice().reverse().map(c => {
      const seller = users.find(u => u.id === c.createdBy)?.username || 'Admin';
      const plan = plans.find(p => p.id === c.planId)?.name || '-';
      const value = `R$ ${(c.commissionValue || 0).toFixed(2).replace('.', ',')}`;
      const status = c.commissionStatus === 'pago' ? 'Pago' : c.commissionStatus === 'cancelado' ? 'Cancelado' : 'Pendente';
      const date = format(new Date(c.createdAt), 'dd/MM/yyyy');

      if (isAdmin) {
        return [date, c.fullName, seller, plan, value, status];
      }
      return [date, c.fullName, plan, value, status];
    });

    const head = isAdmin 
      ? [['Data', 'Cliente', 'Vendedor', 'Plano', 'Valor', 'Status']]
      : [['Data', 'Cliente', 'Plano', 'Valor', 'Status']];

    autoTable(doc, {
      startY: isAdmin ? 75 : 85,
      head: head,
      body: tableData,
      headStyles: { fillColor: [10, 25, 47], textColor: [255, 255, 255] },
      alternateRowStyles: { fillColor: [245, 245, 245] },
    });

    doc.save(`Relatorio_Comissoes_${format(new Date(), 'dd-MM-yyyy')}.pdf`);
  };

  const hasAccess = currentUser?.allowedTabs && currentUser.allowedTabs.length > 0
    ? currentUser.allowedTabs.includes('comissoes')
    : true;

  if (!hasAccess) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500 text-lg">Você não tem permissão para acessar esta página.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Comissões e Valores</h1>
          <p className="text-sm text-gray-500">
            {isAdmin 
              ? 'Controle os valores a pagar para cada vendedor e o status do pagamento.' 
              : 'Acompanhe suas vendas e os valores de comissão a receber.'}
          </p>
        </div>
        <Button onClick={generatePDF} className="gap-2">
          <FileText size={18} /> Baixar Relatório PDF
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 flex items-center gap-4">
          <div className="p-3 bg-yellow-100 text-yellow-600 rounded-full">
            <Clock size={24} />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Total Pendente</p>
            <p className="text-2xl font-bold text-gray-900">
              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalPendente)}
            </p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 flex items-center gap-4">
          <div className="p-3 bg-green-100 text-green-600 rounded-full">
            <CheckCircle size={24} />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Total Pago</p>
            <p className="text-2xl font-bold text-gray-900">
              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalPago)}
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-500">
            <thead className="bg-gray-50 text-xs uppercase text-gray-700">
              <tr>
                <th className="px-6 py-4 font-medium">Data</th>
                <th className="px-6 py-4 font-medium">Cliente</th>
                {isAdmin && <th className="px-6 py-4 font-medium">Vendedor</th>}
                <th className="px-6 py-4 font-medium">Plano</th>
                <th className="px-6 py-4 font-medium">Valor da Comissão</th>
                <th className="px-6 py-4 font-medium">Status</th>
                {isAdmin && <th className="px-6 py-4 font-medium text-right">Ações</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={isAdmin ? 7 : 6} className="px-6 py-8 text-center text-gray-500">
                    Nenhuma venda encontrada.
                  </td>
                </tr>
              ) : (
                filteredCustomers.slice().reverse().map(customer => {
                  const seller = users.find(u => u.id === customer.createdBy)?.username || 'Admin';
                  const plan = plans.find(p => p.id === customer.planId)?.name || '-';
                  const isPaid = customer.commissionStatus === 'pago';
                  const isCancelled = customer.commissionStatus === 'cancelado';

                  return (
                    <tr key={customer.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">{format(new Date(customer.createdAt), 'dd/MM/yyyy')}</td>
                      <td className="px-6 py-4 font-medium text-gray-900">{customer.fullName}</td>
                      {isAdmin && <td className="px-6 py-4">{seller}</td>}
                      <td className="px-6 py-4">{plan}</td>
                      <td className="px-6 py-4">
                        {editingId === customer.id ? (
                          <div className="flex items-center gap-2">
                            <input
                              type="number"
                              step="0.01"
                              className="w-24 px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                              value={editValue}
                              onChange={(e) => setEditValue(e.target.value)}
                              placeholder="0.00"
                            />
                            <select
                              value={editStatus}
                              onChange={(e) => setEditStatus(e.target.value as any)}
                              className="px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="pendente">Pendente</option>
                              <option value="pago">Pago</option>
                              <option value="cancelado">Cancelado</option>
                            </select>
                            <button 
                              onClick={() => handleSaveValue(customer.id)} 
                              className="text-green-600 hover:bg-green-50 p-1.5 rounded transition-colors"
                              title="Salvar"
                            >
                              <Save size={16} />
                            </button>
                            <button 
                              onClick={() => setEditingId(null)} 
                              className="text-red-600 hover:bg-red-50 p-1.5 rounded transition-colors"
                              title="Cancelar"
                            >
                              <X size={16} />
                            </button>
                          </div>
                        ) : (
                          <span className="font-medium text-gray-900">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(customer.commissionValue || 0)}
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                          isPaid ? 'bg-green-100 text-green-800' : 
                          isCancelled ? 'bg-red-100 text-red-800' : 
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {isPaid ? 'Pago' : isCancelled ? 'Cancelado' : 'Pendente'}
                        </span>
                      </td>
                      {isAdmin && (
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => {
                                setEditingId(customer.id);
                                setEditValue((customer.commissionValue || 0).toString());
                                setEditStatus(customer.commissionStatus || 'pendente');
                              }}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                              title="Editar Valor e Status"
                            >
                              <Edit2 size={16} />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
