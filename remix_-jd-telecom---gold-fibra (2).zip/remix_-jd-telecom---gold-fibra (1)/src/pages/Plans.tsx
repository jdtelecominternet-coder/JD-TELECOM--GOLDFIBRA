import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useStore } from '@/store/useStore';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Select';
import { Plus, Edit2, Trash2, X, Search } from 'lucide-react';
import { Navigate } from 'react-router-dom';
import { Plan } from '@/types';

const planSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório'),
  speed: z.string().min(1, 'Velocidade é obrigatória'),
  price: z.number().min(0, 'Valor deve ser positivo'),
  benefits: z.string().min(1, 'Benefícios são obrigatórios'),
  status: z.enum(['active', 'inactive']),
});

type PlanFormData = z.infer<typeof planSchema>;

export const Plans = () => {
  const { plans, addPlan, updatePlan, deletePlan, user } = useStore();
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors },
  } = useForm<PlanFormData>({
    resolver: zodResolver(planSchema),
    defaultValues: {
      status: 'active',
    },
  });

  const onSubmit = (data: PlanFormData) => {
    if (isEditing) {
      updatePlan(isEditing, data);
    } else {
      addPlan({ ...data, id: crypto.randomUUID() });
    }
    handleCloseForm();
  };

  const handleEdit = (plan: Plan) => {
    setIsEditing(plan.id);
    setValue('name', plan.name);
    setValue('speed', plan.speed);
    setValue('price', plan.price);
    setValue('benefits', plan.benefits);
    setValue('status', plan.status);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setIsEditing(null);
    reset({ status: 'active' });
  };

  const filteredPlans = plans.filter(plan => {
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return plan.name.toLowerCase().includes(term) || plan.speed.includes(term);
    }
    return true;
  });

  const hasAccess = user?.allowedTabs && user.allowedTabs.length > 0
    ? user.allowedTabs.includes('planos')
    : user?.role === 'admin';

  if (!hasAccess) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500 text-lg">Você não tem permissão para acessar esta página.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Planos de Internet</h1>
          <p className="text-sm text-gray-500">Gerencie os planos oferecidos aos clientes.</p>
        </div>
        {!showForm && (
          <Button onClick={() => setShowForm(true)} className="gap-2">
            <Plus size={18} /> Novo Plano
          </Button>
        )}
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-800">
              {isEditing ? 'Editar Plano' : 'Cadastrar Novo Plano'}
            </h2>
            <button onClick={handleCloseForm} className="text-gray-400 hover:text-gray-600">
              <X size={20} />
            </button>
          </div>
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Nome do Plano"
                placeholder="Ex: 600 Mega"
                {...register('name')}
                error={errors.name?.message}
              />
              <Input
                label="Velocidade (MB/GB)"
                placeholder="Ex: 600"
                {...register('speed')}
                error={errors.speed?.message}
              />
              <Input
                label="Valor Mensal (R$)"
                type="number"
                step="0.01"
                placeholder="Ex: 99.90"
                {...register('price', { valueAsNumber: true })}
                error={errors.price?.message}
              />
              <Select
                label="Status"
                options={[
                  { value: 'active', label: 'Ativo' },
                  { value: 'inactive', label: 'Inativo' },
                ]}
                {...register('status')}
                error={errors.status?.message}
              />
            </div>
            
            <Input
              label="Benefícios Inclusos"
              placeholder="Ex: Wi-Fi 6, TV, Telefone Fixo"
              {...register('benefits')}
              error={errors.benefits?.message}
            />

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={handleCloseForm}>
                Cancelar
              </Button>
              <Button type="submit">
                {isEditing ? 'Salvar Alterações' : 'Cadastrar Plano'}
              </Button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="relative w-full sm:w-72">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Buscar planos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-500">
            <thead className="bg-gray-50 text-xs uppercase text-gray-700">
              <tr>
                <th className="px-6 py-4 font-medium">Nome do Plano</th>
                <th className="px-6 py-4 font-medium">Velocidade</th>
                <th className="px-6 py-4 font-medium">Valor</th>
                <th className="px-6 py-4 font-medium">Benefícios</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredPlans.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                    Nenhum plano encontrado.
                  </td>
                </tr>
              ) : (
                filteredPlans.map((plan) => (
                  <tr key={plan.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{plan.name}</td>
                    <td className="px-6 py-4">{plan.speed} Mega</td>
                    <td className="px-6 py-4">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(plan.price)}
                    </td>
                    <td className="px-6 py-4 truncate max-w-xs">{plan.benefits}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        plan.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {plan.status === 'active' ? 'Ativo' : 'Inativo'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => handleEdit(plan)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                          title="Editar"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm('Tem certeza que deseja excluir este plano?')) {
                              deletePlan(plan.id);
                            }
                          }}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-md transition-colors"
                          title="Excluir"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
