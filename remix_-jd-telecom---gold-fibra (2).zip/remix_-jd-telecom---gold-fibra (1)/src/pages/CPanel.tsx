import React, { useState } from 'react';
import { useStore } from '@/store/useStore';
import { Shield, Key, Save, Edit2, Check, X } from 'lucide-react';
import { format, addDays } from 'date-fns';

export const CPanel = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const { license, updateLicense, saasPlans, updateSaasPlan } = useStore();
  
  const [editingPlanId, setEditingPlanId] = useState<string | null>(null);
  const [editPlanData, setEditPlanData] = useState({ name: '', periodDays: 0, price: 0 });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'master123') {
      setIsAuthenticated(true);
      setError('');
    } else {
      setError('Senha incorreta.');
    }
  };

  const handleSavePlan = (id: string) => {
    updateSaasPlan(id, editPlanData);
    setEditingPlanId(null);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-8">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4 shadow-lg">
              <Shield size={32} className="text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">cPanel de Licenças</h1>
            <p className="text-sm text-gray-500 mt-1">Acesso restrito ao administrador do sistema</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Senha Mestra</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Key size={18} className="text-gray-400" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                  placeholder="Digite a senha..."
                  required
                />
              </div>
              {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-200 font-medium transition-all"
            >
              Acessar Painel
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-5xl mx-auto space-y-8">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center shadow-md">
            <Shield size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Painel de Controle do Sistema</h1>
            <p className="text-gray-500">Gerencie a licença de uso e os valores dos planos de assinatura.</p>
          </div>
        </div>

        {/* License Control */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-6 border-b border-gray-200 bg-gray-50">
            <h2 className="text-lg font-bold text-gray-900">Status da Licença Atual</h2>
          </div>
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Status do Sistema</label>
              <select
                value={license.status}
                onChange={(e) => updateLicense({ status: e.target.value as any })}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="trial">Período de Teste (Trial)</option>
                <option value="active">Ativo (Pago)</option>
                <option value="expired">Expirado / Bloqueado</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Data de Expiração</label>
              <input
                type="datetime-local"
                value={license.expiresAt.slice(0, 16)}
                onChange={(e) => updateLicense({ expiresAt: new Date(e.target.value).toISOString() })}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="md:col-span-2 flex gap-3">
              <button
                onClick={() => updateLicense({ status: 'trial', expiresAt: addDays(new Date(), 7).toISOString() })}
                className="px-4 py-2 bg-yellow-100 text-yellow-800 rounded-lg hover:bg-yellow-200 font-medium text-sm transition-colors"
              >
                Renovar Teste (+7 dias)
              </button>
              <button
                onClick={() => updateLicense({ status: 'active', expiresAt: addDays(new Date(), 30).toISOString() })}
                className="px-4 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 font-medium text-sm transition-colors"
              >
                Ativar Plano (+30 dias)
              </button>
              <button
                onClick={() => updateLicense({ status: 'expired', expiresAt: new Date().toISOString() })}
                className="px-4 py-2 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 font-medium text-sm transition-colors"
              >
                Bloquear Sistema Agora
              </button>
            </div>
          </div>
        </div>

        {/* Plans Control */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-6 border-b border-gray-200 bg-gray-50">
            <h2 className="text-lg font-bold text-gray-900">Valores de Assinatura do Sistema</h2>
            <p className="text-sm text-gray-500 mt-1">Estes são os valores que o cliente verá quando a licença expirar.</p>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {saasPlans.map(plan => (
                <div key={plan.id} className="border border-gray-200 rounded-lg p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  {editingPlanId === plan.id ? (
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Nome do Plano</label>
                        <input
                          type="text"
                          value={editPlanData.name}
                          onChange={(e) => setEditPlanData({ ...editPlanData, name: e.target.value })}
                          className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Dias de Acesso</label>
                        <input
                          type="number"
                          value={editPlanData.periodDays}
                          onChange={(e) => setEditPlanData({ ...editPlanData, periodDays: parseInt(e.target.value) || 0 })}
                          className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Valor (R$)</label>
                        <input
                          type="number"
                          step="0.01"
                          value={editPlanData.price}
                          onChange={(e) => setEditPlanData({ ...editPlanData, price: parseFloat(e.target.value) || 0 })}
                          className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900 text-lg">{plan.name}</h3>
                      <p className="text-sm text-gray-500">
                        Libera {plan.periodDays} dias de acesso por <strong className="text-gray-900">R$ {plan.price.toFixed(2).replace('.', ',')}</strong>
                      </p>
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    {editingPlanId === plan.id ? (
                      <>
                        <button onClick={() => handleSavePlan(plan.id)} className="p-2 bg-green-100 text-green-700 rounded hover:bg-green-200 transition-colors">
                          <Check size={20} />
                        </button>
                        <button onClick={() => setEditingPlanId(null)} className="p-2 bg-red-100 text-red-700 rounded hover:bg-red-200 transition-colors">
                          <X size={20} />
                        </button>
                      </>
                    ) : (
                      <button 
                        onClick={() => {
                          setEditingPlanId(plan.id);
                          setEditPlanData({ name: plan.name, periodDays: plan.periodDays, price: plan.price });
                        }} 
                        className="p-2 bg-blue-50 text-blue-600 rounded hover:bg-blue-100 transition-colors flex items-center gap-2"
                      >
                        <Edit2 size={16} /> <span className="text-sm font-medium">Editar</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
