import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '@/store/useStore';
import { Send, User as UserIcon } from 'lucide-react';
import { format } from 'date-fns';
import { Navigate } from 'react-router-dom';

export const Chat = () => {
  const { user: currentUser, users, messages, sendMessage, markAsRead } = useStore();
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const chatUsers = users.filter(u => u.id !== currentUser?.id);

  useEffect(() => {
    if (selectedUserId && currentUser) {
      const hasUnread = messages.some(m => m.senderId === selectedUserId && m.receiverId === currentUser.id && !m.read);
      if (hasUnread) {
        markAsRead(selectedUserId, currentUser.id);
      }
    }
  }, [selectedUserId, messages, currentUser, markAsRead]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selectedUserId]);

  if (!currentUser) return <Navigate to="/login" replace />;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedUserId) return;
    
    sendMessage({
      senderId: currentUser.id,
      receiverId: selectedUserId,
      content: newMessage.trim(),
    });
    setNewMessage('');
  };

  return (
    <div className="h-[calc(100vh-8rem)] bg-white rounded-lg shadow-sm border border-gray-200 flex overflow-hidden">
      {/* Users List Sidebar */}
      <div className="w-80 border-r border-gray-200 flex flex-col bg-gray-50">
        <div className="p-4 border-b border-gray-200 bg-white">
          <h2 className="text-lg font-bold text-gray-900">Mensagens</h2>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {chatUsers.map(u => {
            const unreadFromUser = messages.filter(m => m.senderId === u.id && m.receiverId === currentUser.id && !m.read).length;
            return (
              <button
                key={u.id}
                onClick={() => setSelectedUserId(u.id!)}
                className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors text-left mb-1 ${selectedUserId === u.id ? 'bg-blue-50 border border-blue-100' : 'hover:bg-gray-100 border border-transparent'}`}
              >
                <div className="relative">
                  {u.photo ? (
                    <img src={u.photo} alt={u.username} className="w-12 h-12 rounded-full object-cover" />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                      <UserIcon size={24} className="text-gray-500" />
                    </div>
                  )}
                  <span className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-white ${u.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></span>
                </div>
                <div className="flex-1 overflow-hidden">
                  <div className="font-medium text-gray-900 truncate">{u.username}</div>
                  <div className="text-xs text-gray-500 capitalize">{u.role}</div>
                </div>
                {unreadFromUser > 0 && (
                  <span className="bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                    {unreadFromUser}
                  </span>
                )}
              </button>
            )
          })}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-white">
        {!selectedUserId ? (
          <div className="flex-1 flex items-center justify-center text-gray-400 flex-col gap-4">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center">
              <UserIcon size={40} className="text-gray-300" />
            </div>
            <p>Selecione um usuário para iniciar uma conversa</p>
          </div>
        ) : (
          <>
            {/* Chat Header */}
            <div className="bg-white p-4 border-b border-gray-200 flex items-center gap-3">
              <div className="relative">
                {users.find(u => u.id === selectedUserId)?.photo ? (
                  <img src={users.find(u => u.id === selectedUserId)?.photo} alt="User" className="w-10 h-10 rounded-full object-cover" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                    <UserIcon size={20} className="text-gray-400" />
                  </div>
                )}
                <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${users.find(u => u.id === selectedUserId)?.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></span>
              </div>
              <div>
                <div className="font-bold text-gray-900">{users.find(u => u.id === selectedUserId)?.username}</div>
                <div className="text-xs text-gray-500">{users.find(u => u.id === selectedUserId)?.isOnline ? 'Online agora' : 'Offline'}</div>
              </div>
            </div>
            
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
              {messages
                .filter(m => (m.senderId === currentUser.id && m.receiverId === selectedUserId) || (m.senderId === selectedUserId && m.receiverId === currentUser.id))
                .map(m => {
                  const isMine = m.senderId === currentUser.id;
                  return (
                    <div key={m.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[70%] rounded-2xl p-4 shadow-sm ${isMine ? 'bg-blue-600 text-white rounded-br-none' : 'bg-white border border-gray-100 text-gray-800 rounded-bl-none'}`}>
                        <p className="text-sm leading-relaxed">{m.content}</p>
                        <span className={`text-[10px] mt-2 block text-right ${isMine ? 'text-blue-200' : 'text-gray-400'}`}>
                          {format(new Date(m.timestamp), 'HH:mm')}
                        </span>
                      </div>
                    </div>
                  );
                })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={handleSend} className="p-4 border-t border-gray-200 bg-white flex gap-3 items-center">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Digite sua mensagem..."
                className="flex-1 border border-gray-300 rounded-full px-6 py-3 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
              />
              <button 
                type="submit" 
                disabled={!newMessage.trim()}
                className="bg-blue-600 text-white p-3 rounded-full hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
              >
                <Send size={20} />
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
