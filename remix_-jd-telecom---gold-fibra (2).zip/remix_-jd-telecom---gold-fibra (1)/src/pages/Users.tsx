import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useStore } from '@/store/useStore';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Select';
import { Plus, Edit2, Trash2, X, Search } from 'lucide-react';
import { Navigate } from 'react-router-dom';
import { User } from '@/types';

const userSchema = z.object({
  username: z.string().min(3, 'Usuário deve ter no mínimo 3 caracteres'),
  password: z.string().min(6, 'Senha deve ter no mínimo 6 caracteres'),
  role: z.enum(['admin', 'atendente']),
  defaultCommission: z.number().min(0, 'Valor deve ser positivo').optional(),
  allowedTabs: z.array(z.string()).optional(),
  photo: z.string().optional(),
});

type UserFormData = z.infer<typeof userSchema>;

export const Users = () => {
  const { users, addUser, updateUser, deleteUser, user: currentUser } = useStore();
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors },
  } = useForm<UserFormData>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      role: 'atendente',
    },
  });

  const onSubmit = (data: UserFormData) => {
    if (isEditing) {
      updateUser(isEditing, data);
    } else {
      addUser({ ...data, id: crypto.randomUUID(), createdAt: new Date().toISOString() });
    }
    handleCloseForm();
  };

  const handleEdit = (user: User) => {
    setIsEditing(user.id!);
    setValue('username', user.username);
    setValue('password', user.password || '');
    setValue('role', user.role as 'admin' | 'atendente');
    setValue('defaultCommission', user.defaultCommission || 0);
    setValue('allowedTabs', user.allowedTabs || []);
    setValue('photo', user.photo || '');
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setIsEditing(null);
    reset({ role: 'atendente', username: '', password: '', defaultCommission: 0, allowedTabs: [], photo: '' });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setValue('photo', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const filteredUsers = users.filter(u => {
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return u.username.toLowerCase().includes(term) || u.role.toLowerCase().includes(term);
    }
    return true;
  });

  const hasAccess = currentUser?.allowedTabs && currentUser.allowedTabs.length > 0
    ? currentUser.allowedTabs.includes('usuarios')
    : currentUser?.role === 'admin';

  if (!hasAccess) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500 text-lg">Você não tem permissão para acessar esta página.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Cadastro de Usuários</h1>
          <p className="text-sm text-gray-500">Gerencie os usuários com acesso ao sistema.</p>
        </div>
        {!showForm && (
          <Button onClick={() => setShowForm(true)} className="gap-2">
            <Plus size={18} /> Novo Usuário
          </Button>
        )}
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-800">
              {isEditing ? 'Editar Usuário' : 'Cadastrar Novo Usuário'}
            </h2>
            <button onClick={handleCloseForm} className="text-gray-400 hover:text-gray-600">
              <X size={20} />
            </button>
          </div>
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Foto de Perfil
                </label>
                <div className="flex items-center gap-4">
                  {watch('photo') ? (
                    <img src={watch('photo')} alt="Preview" className="w-16 h-16 rounded-full object-cover border border-gray-300" />
                  ) : (
                    <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center border border-gray-300">
                      <span className="text-gray-400 text-xs text-center">Sem<br/>foto</span>
                    </div>
                  )}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                  />
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                label="Nome de Usuário"
                placeholder="Ex: joao.silva"
                {...register('username')}
                error={errors.username?.message}
              />
              <Input
                label="Senha"
                type="text"
                placeholder="******"
                {...register('password')}
                error={errors.password?.message}
              />
              <Select
                label="Nível de Acesso"
                options={[
                  { value: 'admin', label: 'Administrador' },
                  { value: 'atendente', label: 'Atendente' },
                ]}
                {...register('role')}
                error={errors.role?.message}
              />
              <Input
                label="Comissão Padrão (R$)"
                type="number"
                step="0.01"
                placeholder="Ex: 50.00"
                {...register('defaultCommission', { valueAsNumber: true })}
                error={errors.defaultCommission?.message}
              />
            </div>

            <div className="md:col-span-3">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Permissões de Acesso (Abas Liberadas)
              </label>
              <div className="flex flex-wrap gap-4 p-4 bg-gray-50 rounded-md border border-gray-200">
                {[
                  { id: 'clientes', label: 'Cadastro de Clientes' },
                  { id: 'planos', label: 'Cadastro de Planos' },
                  { id: 'usuarios', label: 'Cadastro de Usuários' },
                  { id: 'comissoes', label: 'Comissões e Valores' },
                ].map(tab => (
                  <label key={tab.id} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      value={tab.id}
                      {...register('allowedTabs')}
                      className="w-4 h-4 text-blue-600 bg-white border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="text-sm text-gray-700">{tab.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={handleCloseForm}>
                Cancelar
              </Button>
              <Button type="submit">
                {isEditing ? 'Salvar Alterações' : 'Cadastrar Usuário'}
              </Button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="relative w-full sm:w-72">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Buscar usuários..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-500">
            <thead className="bg-gray-50 text-xs uppercase text-gray-700">
              <tr>
                <th className="px-6 py-4 font-medium">Usuário</th>
                <th className="px-6 py-4 font-medium">Nível de Acesso</th>
                <th className="px-6 py-4 font-medium">Abas Liberadas</th>
                <th className="px-6 py-4 font-medium">Comissão Padrão</th>
                <th className="px-6 py-4 font-medium">Data de Criação</th>
                <th className="px-6 py-4 font-medium text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                    Nenhum usuário encontrado.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 font-medium text-gray-900">
                    <div className="flex items-center gap-3">
                      {user.photo ? (
                        <img src={user.photo} alt={user.username} className="w-8 h-8 rounded-full object-cover" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                          <span className="text-gray-500 text-xs">{user.username.charAt(0).toUpperCase()}</span>
                        </div>
                      )}
                      {user.username}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                      user.role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {user.role === 'admin' ? 'Administrador' : 'Atendente'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1">
                      {(user.allowedTabs || []).map(tab => (
                        <span key={tab} className="inline-flex items-center rounded-full bg-gray-100 px-2 py-0.5 text-[10px] font-medium text-gray-600 uppercase">
                          {tab}
                        </span>
                      ))}
                      {(!user.allowedTabs || user.allowedTabs.length === 0) && (
                        <span className="text-xs text-gray-400">Padrão ({user.role})</span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {user.defaultCommission ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(user.defaultCommission) : '-'}
                  </td>
                  <td className="px-6 py-4">
                    {user.createdAt ? new Date(user.createdAt).toLocaleDateString('pt-BR') : '-'}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => handleEdit(user)}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                        title="Editar"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button
                        onClick={() => {
                          if (user.id === currentUser?.id) {
                            setDeleteError('Você não pode excluir seu próprio usuário enquanto estiver logado.');
                            return;
                          }
                          setDeleteConfirmId(user.id!);
                        }}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded-md transition-colors"
                        title="Excluir"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              )))}
            </tbody>
          </table>
        </div>
      </div>
      {/* Delete Error Modal */}
      {deleteError && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Ação não permitida</h3>
            <p className="text-gray-600 mb-6">{deleteError}</p>
            <div className="flex justify-end">
              <Button onClick={() => setDeleteError(null)}>Entendi</Button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Confirmar Exclusão</h3>
            <p className="text-gray-600 mb-6">Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.</p>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setDeleteConfirmId(null)}>Cancelar</Button>
              <Button 
                className="bg-red-600 hover:bg-red-700 text-white"
                onClick={() => {
                  deleteUser(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
              >
                Excluir
              </Button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
