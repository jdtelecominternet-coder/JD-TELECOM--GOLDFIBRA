import React from 'react';
import { useStore } from '@/store/useStore';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Save } from 'lucide-react';
import { Navigate } from 'react-router-dom';

const settingsSchema = z.object({
  companyName: z.string().min(1, 'Nome da empresa é obrigatório'),
  companySubtitle: z.string().min(1, 'Subtítulo é obrigatório'),
  logo: z.string().optional(),
  defaultObservation: z.string().optional(),
});

type SettingsFormData = z.infer<typeof settingsSchema>;

export const Settings = () => {
  const { settings, updateSettings, user } = useStore();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<SettingsFormData>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      companyName: settings.companyName,
      companySubtitle: settings.companySubtitle,
      logo: settings.logo || '',
      defaultObservation: settings.defaultObservation || '',
    },
  });

  const [showSuccess, setShowSuccess] = React.useState(false);

  if (user?.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setValue('logo', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = (data: SettingsFormData) => {
    updateSettings(data);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Configurações do Sistema</h1>
        <p className="text-sm text-gray-500">
          Altere o nome e o subtítulo da empresa que aparecem no menu e nos relatórios.
        </p>
      </div>

      {showSuccess && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative" role="alert">
          <span className="block sm:inline">Configurações salvas com sucesso!</span>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Logo da Empresa (Imagem)
              </label>
              <div className="flex items-center gap-4">
                {watch('logo') ? (
                  <img src={watch('logo')} alt="Logo Preview" className="w-16 h-16 object-contain border border-gray-300 rounded bg-white" />
                ) : (
                  <div className="w-16 h-16 rounded bg-gray-100 flex items-center justify-center border border-gray-300">
                    <span className="text-gray-400 text-xs text-center">Sem<br/>Logo</span>
                  </div>
                )}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                />
              </div>
            </div>

            <Input
              label="Nome da Empresa (Texto)"
              placeholder="Ex: JD Telecom"
              {...register('companyName')}
              error={errors.companyName?.message}
            />
            <Input
              label="Subtítulo da Empresa"
              placeholder="Ex: GOLD FIBRA"
              {...register('companySubtitle')}
              error={errors.companySubtitle?.message}
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Observação Padrão (Contratos)
              </label>
              <textarea
                className="flex w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={4}
                placeholder="Ex: Equipamentos cedidos em regime de comodato..."
                {...register('defaultObservation')}
              />
              <p className="mt-1 text-xs text-gray-500">
                Esta observação será fixada em todos os novos cadastros de clientes e impressa nos contratos.
              </p>
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t">
            <Button type="submit" className="gap-2">
              <Save size={18} /> Salvar Configurações
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
