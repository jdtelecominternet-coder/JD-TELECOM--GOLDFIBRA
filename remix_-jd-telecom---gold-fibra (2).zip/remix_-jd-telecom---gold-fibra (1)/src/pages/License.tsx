import React from 'react';
import { useStore } from '@/store/useStore';
import { ShieldAlert, CheckCircle2, Clock } from 'lucide-react';
import { addDays } from 'date-fns';
import { useNavigate } from 'react-router-dom';

export const License = () => {
  const { saasPlans, updateLicense } = useStore();
  const navigate = useNavigate();

  const handleSimulatePurchase = (days: number) => {
    // In a real app, this would redirect to a payment gateway (Stripe, MercadoPago, etc)
    // For this demo, we simulate a successful purchase
    alert(`Simulação de Pagamento: Você comprou ${days} dias de acesso!`);
    updateLicense({
      status: 'active',
      expiresAt: addDays(new Date(), days).toISOString()
    });
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShieldAlert size={40} className="text-red-500" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">Sua licença expirou</h1>
          <p className="text-xl text-gray-400">
            Para continuar utilizando o sistema JD Telecom, escolha um dos planos abaixo.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {saasPlans.map((plan, index) => (
            <div 
              key={plan.id} 
              className={`bg-gray-800 rounded-2xl p-8 border ${index === 1 ? 'border-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.3)] relative transform md:-translate-y-4' : 'border-gray-700'}`}
            >
              {index === 1 && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-bold">
                  MAIS POPULAR
                </div>
              )}
              <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-extrabold text-white">R$ {plan.price.toFixed(2).replace('.', ',')}</span>
              </div>
              <p className="text-gray-400 mb-8">Acesso completo ao sistema por {plan.periodDays} dias.</p>
              
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3 text-gray-300">
                  <CheckCircle2 size={20} className="text-green-500" />
                  <span>Cadastro ilimitado</span>
                </li>
                <li className="flex items-center gap-3 text-gray-300">
                  <CheckCircle2 size={20} className="text-green-500" />
                  <span>Chat interno</span>
                </li>
                <li className="flex items-center gap-3 text-gray-300">
                  <CheckCircle2 size={20} className="text-green-500" />
                  <span>Gestão de comissões</span>
                </li>
                <li className="flex items-center gap-3 text-gray-300">
                  <CheckCircle2 size={20} className="text-green-500" />
                  <span>Suporte técnico</span>
                </li>
              </ul>

              <button
                onClick={() => handleSimulatePurchase(plan.periodDays)}
                className={`w-full py-4 rounded-xl font-bold transition-all ${
                  index === 1 
                    ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                    : 'bg-gray-700 hover:bg-gray-600 text-white'
                }`}
              >
                Assinar Agora
              </button>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center text-gray-500 text-sm flex items-center justify-center gap-2">
          <Clock size={16} /> Pagamento seguro e liberação imediata.
        </div>
      </div>
    </div>
  );
};
